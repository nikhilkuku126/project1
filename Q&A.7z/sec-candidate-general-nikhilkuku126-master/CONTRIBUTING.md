# Contributing

This is the default CONTRIBUTING.md file for Qantas Loyalty. It lays out contribution guidelines in the absence of any
team specific CONTRIBUTING.md.

When contributing to this repository ensure that the work you are doing has a corresponding Jira ticket in the
appropriate project. Qantas Jira can be found at [jira.qantas.com.au](https://jira.qantas.com.au/). You should include
the Jira ticket number in your commit messages.

## Git Workflow

We use the [Skullcandy workflow](https://www.endpoint.com/blog/2014/05/02/git-workflows-that-work). Here's the
breakdown:

- Use a feature branch for each piece of work (branch from master)
- PR back to master when you're ready to go to prod
- There is a seperate QA branch called 'develop'. This branch goes to dev and sit environments. You do not need a PR to
  this branch
- Blow away develop branch away and recreate from master regularly.
- We do not enforce a branch naming strategy but we suggest just using the Jira ID or whatever the 'Create branch' link
  in Jira suggests

## Pull Request Process

1. Any one with access to this repository can raise a Pull Request
2. Merging to master is controlled by the .github/CODEOWNERS file
3. Ensure you are up to date with master. We prefer `git rebase master` rather than `git merge master`
4. Two approvals are required before merging is allowed
5. A passing CI build is required before merging is allowed

## Versioning

Versioning for this project should be handled as part of the CI process. Version numbers follow the following format:

Format: {YY}.{MMDD}.{BUILD_NUMBER} Example: 20.0512.23

## Style

Qantas Loyalty have a styleguide that can be found at https://github.com/qantasloyalty/styleguide.
