# lto-candidate-testing-ansible

This is the git repository lto-candidate-testing-general.

It contains a number of questions to test your technical knowledge.

## How to complete this test

This test is comprised of a number of questions.  All questions can be found in QUESTIONS.md.

Complete the test by writing your answers underneath each question in the QUESTIONS.md file, commiting your changes and then pushing your changes
to the Git origin.  Please make your changes on a new Git branch.
