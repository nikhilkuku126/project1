# TechOps Technical Questions

## DevOps

1. Why do you think more and more companies are embracing "DevOps"?
DevOps that enables the rapid, agile development of software and the softwares are scalable and reliable. It aimed to automates most the repeatable work in software development process and also it enforces the best practice in the software development and operations.

## VCS

2. Describe any VCS branching strategies that you have used.

We use BitBucket as our SCM/VCM. To implement a new feature, we used to create a feature branch from our master branch(production branch). We will our feature development on feature branch. Once the development is over we will merge our feature branch changes to development branch for dev testing followed by we will merge this changes to integration for second round of testing. If everthing goes well, We will merge our changes to master(production)

3. Which VCS tool are you most comfortable with?.

I am comfortable with GIT(Bitbucket, GitLab, Github).

4. Using Git, describe how you would squash the last N commits into a single commit, preserving any commit messages.

`git rebase -i HEAD~3`. Here I am squash the last 3 commits

## CI/CD

5. Explain the difference between CI and CD.
CI: 
Continuous integration means Developers are merging there code changes to main branch as soon as possible. The developer changes are validated by creating a build and running some test over the build. This avoids the integration challenges that can happen when waiting for release day to merge changes into the release branch. It is a testing automation to check that the application is not broken whenever new commits are integrated into the main branch.

CD: 
Continuous deployment/Continuoous delivery.
Once the new code changes are pushed to the branch on top of above validation. It is an another automated mechanism to deploy the new code changes to testing environment/ Production. 

6. What metrics would you monitor to ensure that your CI pipeline was effective?

We used to collect 
1. Unit test failure metrics
2. Unit test coverage metrics  
3. Sonar qube code smell metrics. 
4. Third Package/ Module vulnerability metrics

## Security

7. What benefits does TLS have over SSL?
SSL provides keyed message authentication, TLS uses the more secure Key-Hashing for Message Authentication Code (HMAC) to ensure that a record cannot be altered during transmission over an open network such as the Internet.

8. An audit has been run at your company and a number of API credentials have been discovered in source control.  What steps would you take to secure
these credentials and ensure there is no longer a risk to the company?

1. Credentials should be stored in vault or AWS Secret managers or Some secured place and the application has to retrive those credentials directly from the stored location. 

2. To prevent this We enable a check in CI part. This has to analysis the code for any API credentials. If found fail the CI build.

9. Explain the difference in behavior when trying to connect to a port that is protected by iptables with a DROP rule opposed to a REJECT rule.

DROP rules: - UDP packets will be dropped and the behavior will be the same as connecting to an unfirewalled port with no service. - TCP packets will return an ACK/RST which is the same response that an open port with no service on it will respond with. Some routers will respond with and ACK/RST on behalf of servers which are down.

REJECT rules an ICMP packet is sent indicating the port is unavailable.

## Incident Management

10. What is an SLI?  What is it used for?  How does it differ from an SLA?

SLI - Service level Indicator. It is a metrics that was collected from the production application and It indicates the availability of the service to serve the user request.

SLA - Service level Agreement. This is something the application owner commited to the end user to give the application at some level of availability percentage.


11. After an incident has been remediated a post-mortem is called.  What is the purpose of a post-mortem?  What do you think the most important outcomes of a post-mortem are?

It is important to understand what made this incident, how we can avoid this in future and going forward What are all remediation steps that has to be taken.

## Containers

12. Can you name 3 major advantages of containerization (e.g. Docker) over virtualization (e.g. vSphere)?

1. Containerized application can run in any os machine. 
2. Application is not going to be an infra dependent/ Platform dependent.
3. All the required components of applicatns are packed allong with the containerized application.

13. What are the benefits of a container orchestration platform such as K8 or ECS?
 Container are managed by them we no need to put additional effort likr
 1. Scaling the containers based on metrics.
 2. Draining the unhealthy containers and attaching new containers.
 3. Deploying the updated containers.
 4. Collecting container metrics.


## Finally...

14. How would you prepare for a migration of a SQL database from a hosted data centre to the cloud?

 Every cloud provider have their own service to migrate the SQL database from data center to the cloud. I will make use of that cloud provider service to migrate. Aws provider AWS Database Migration Service (AWS DMS)

