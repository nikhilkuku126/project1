### Part A

## Approach (Assumtion users are not created initally)
Since join had mentioned that few more marketing members also need the same kind of access. So, Instead of replicating the iam-user code again and again for new members. I the existing iam-user as an iam-user module and I created a main.tf under root directory and from this main.tf I Will utilize the iam-user module for user creation with some default permission (S3 permissions) . This can be overrided based on user. 

1. All the users will have some default permission, If needed we can override the `default_onboarding_access` permissions.
2. `User` variable in main.tf Will take 2 inputs. One is user name and another one is additional permission.
3. If any users need additional permissions we can directly update the user policy.
4. Currently, I have added `jane.doe@qantasloyalty.com` in User list With default permission.

### Part B

## Approach

### Part C

## Approach

